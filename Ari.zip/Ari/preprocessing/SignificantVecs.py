import numpy as np
import pandas as pd
import scipy as sci

df = pd.read_csv("test.csv")


for vector in df:
	for value in vector:
		print value